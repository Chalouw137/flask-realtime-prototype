# Flask Real-Time Prototype

A simple Flask app with real-time support using Flask-SocketIO.